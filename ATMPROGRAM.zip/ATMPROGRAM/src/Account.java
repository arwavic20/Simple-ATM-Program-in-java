class Account {
    private String accountNumber;
    private double balance;

    public Account(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    public double getBalance() {
        return balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposit successful. New balance: " + balance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful. New balance: " + balance);
        } else {
            System.out.println("Invalid withdrawal amount or insufficient funds.");
        }
    }

    public boolean transfer(Account toAccount, double amount, boolean sameBank) {
        double transferFee = sameBank ? 0 : 0.001 * amount;
        double totalAmount = amount + transferFee;

        if (totalAmount <= balance) {
            this.withdraw(totalAmount);
            toAccount.deposit(amount);
            System.out.println("Transfer successful. New balance: " + balance);
            return true;
        } else {
            System.out.println("Insufficient funds for transfer.");
            return false;
        }
    }
}


